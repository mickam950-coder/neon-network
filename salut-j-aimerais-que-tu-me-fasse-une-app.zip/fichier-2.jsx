import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';

const socket = io('http://localhost:3000');

function App() {
  const [username, setUsername] = useState('');
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    socket.on('receiveMessage', (data) => {
      setMessages(prev => [...prev, data]);
    });

    socket.on('userJoined', (username) => {
      alert(`${username} a rejoint le chat !`);
    });

    return () => {
      socket.off('receiveMessage');
      socket.off('userJoined');
    };
  }, []);

  const sendMessage = () => {
    socket.emit('sendMessage', message);
    setMessage('');
  };

  return (
    <div>
      <h1>NEON-NETWORK</h1>
      <input
        type="text"
        placeholder="Nom d'utilisateur"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <button onClick={() => socket.emit('join', username)}>Rejoindre</button>
      <div>
        {messages.map((msg, i) => (
          <div key={i}>{msg.username}: {msg.message}</div>
        ))}
      </div>
      <input
        type="text"
        placeholder="Envoyer un message"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <button onClick={sendMessage}>Envoyer</button>
    </div>
  );
}

export default App;