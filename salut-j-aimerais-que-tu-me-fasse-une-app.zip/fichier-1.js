const express = require('express');
const socketio = require('socket.io');
const http = require('http');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketio(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());

let users = {};

io.on('connection', (socket) => {
  socket.on('join', (username) => {
    users[socket.id] = username;
    socket.broadcast.emit('userJoined', username);
  });

  socket.on('sendMessage', (data) => {
    io.emit('receiveMessage', {
      username: users[socket.id],
      message: data
    });
  });

  socket.on('disconnect', () => {
    delete users[socket.id];
    io.emit('userLeft', users[socket.id]);
  });
});

server.listen(3000, () => {
  console.log('Server running on port 3000');
});